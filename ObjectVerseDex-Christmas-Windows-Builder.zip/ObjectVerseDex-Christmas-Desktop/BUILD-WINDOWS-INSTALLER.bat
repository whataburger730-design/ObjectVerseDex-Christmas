@echo off
setlocal
cd /d "%~dp0"
title ObjectVerse-Dex Christmas Calendar - Windows Installer Builder
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js is required to build the installer.
 echo Install the LTS version from https://nodejs.org/ then run this file again.
 pause
 exit /b 1
)
call npm install
if errorlevel 1 (
 echo Installation of build dependencies failed. Check your internet connection.
 pause
 exit /b 1
)
call npm run dist:installer
if errorlevel 1 (
 echo The Windows installer build failed. See the error above.
 pause
 exit /b 1
)
echo.
echo Installer generated in the dist folder.
start "" "%~dp0dist"
pause
